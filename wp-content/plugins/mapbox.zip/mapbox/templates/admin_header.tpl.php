<div class="wrap">
	<?php w2mb_renderMessages(); ?>
	