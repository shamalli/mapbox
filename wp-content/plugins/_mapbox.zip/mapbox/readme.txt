﻿=== MapBox Locator ===
Contributors: Mihail Chepovskiy
Donate link: http://www.salephpscripts.com/
Tags: directions, MapBox map, listing, directory, markers, clusters, search form, places, polygons, routes, visual composer, wordpress, wpml, youtube
Requires at least: 3.6.2
Tested up to: 5.4
Stable tag: tags/1.0.0
License: Commercial

== Description ==

MapBox Locator plugin for Wordpress to build custom MapBox maps with high quality markers and additional instruments. Frontend submission form allows users to submit markers and
listings from frontend of WordPress site. Search form filters markers and listings by categories, locations and content fields. Draw Area functionality is
the most perfect tool to search needed places in accurately pictured area.

Look at our [demo](http://www.salephpscripts.com/wordpress_maps/demo/)

== Changelog ==

= Version 1.0.0 =
* Initial release
