# Vafpress Framework I18n

Help us translating the framework:

https://www.transifex.com/projects/p/vafpress-framework/

## Contributors

Join those awesome contributors:

#### Indonesian
---
Vafour ([http://vafour.com](http://vafour.com))

#### Japanese
---
Alexander Chen ([http://arkross.com](http://arkross.com))

#### Turkish
---
M. Kaan Karakaya ([http://krky.org](http://krky.org))

#### Dutch
---
Patrick Heiloo ([http://www.patrickheiloo.nl/](http://www.patrickheiloo.nl/))

#### German
---
Predrag Gasic ([https://twitter.com/VisualSuccess](https://twitter.com/VisualSuccess))

#### Polish
---
Krystian Podemski ([http://www.podemski.info/](http://www.podemski.info/))

#### Spanish
---
Isidro Lopez Castillo ([http://www.zaytec.com](http://www.zaytec.com))

See you there!
