<div class="w2gm-content">
	<?php w2gm_renderMessages(); ?>

	<div class="w2gm-submit-section-adv">
		<?php w2gm_login_form(); ?>
	</div>
</div>