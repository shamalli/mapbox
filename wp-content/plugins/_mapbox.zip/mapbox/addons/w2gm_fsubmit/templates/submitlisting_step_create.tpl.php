<div class="w2gm-content">
	<?php w2gm_renderMessages(); ?>

	<h3><?php echo apply_filters('w2gm_create_option', __('Submit new listing', 'W2GM')); ?></h3>

	<form action="<?php echo w2gm_submitUrl(array('level' => $w2gm_instance->current_listing->level->id)); ?>" method="POST" enctype="multipart/form-data">
		<input type="hidden" name="listing_id" value="<?php echo $w2gm_instance->current_listing->post->ID; ?>" />
		<input type="hidden" name="listing_id_hash" value="<?php echo md5($w2gm_instance->current_listing->post->ID . wp_salt()); ?>" />
		<?php wp_nonce_field('w2gm_submit', '_submit_nonce'); ?>

		<?php if (!is_user_logged_in() && (get_option('w2gm_fsubmit_login_mode') == 2 || get_option('w2gm_fsubmit_login_mode') == 3)): ?>
		<div class="w2gm-submit-section w2gm-submit-section-contact-info">
			<h3 class="w2gm-submit-section-label"><?php _e('User info', 'W2GM'); ?></h3>
			<div class="w2gm-submit-section-inside">
				<label class="w2gm-fsubmit-contact"><?php _e('Your Name', 'W2GM'); ?><?php if (get_option('w2gm_fsubmit_login_mode') == 2): ?><span class="w2gm-red-asterisk">*</span><?php endif; ?></label>
				<input type="text" name="w2gm_user_contact_name" value="<?php echo esc_attr($frontend_controller->w2gm_user_contact_name); ?>" class="w2gm-form-control" style="width: 100%;" />

				<label class="w2gm-fsubmit-contact"><?php _e('Your Email', 'W2GM'); ?><?php if (get_option('w2gm_fsubmit_login_mode') == 2): ?><span class="w2gm-red-asterisk">*</span><?php endif; ?></label>
				<input type="text" name="w2gm_user_contact_email" value="<?php echo esc_attr($frontend_controller->w2gm_user_contact_email); ?>" class="w2gm-form-control" style="width: 100%;" />
				<p class="w2gm-description"><?php _e("Login information will be sent to your email after submission", "W2GM"); ?></p>
			</div>
		</div>
		<?php endif; ?>

		<div class="w2gm-submit-section w2gm-submit-section-title">
			<h3 class="w2gm-submit-section-label"><?php _e('Listing title', 'W2GM'); ?><span class="w2gm-red-asterisk">*</span></h3>
			<div class="w2gm-submit-section-inside">
				<input type="text" name="post_title" style="width: 100%" class="w2gm-form-control" value="<?php if ($w2gm_instance->current_listing->post->post_title != __('Auto Draft', 'W2GM')) echo esc_attr($w2gm_instance->current_listing->post->post_title); ?>" />
			</div>
		</div>

		<?php if (post_type_supports(W2GM_POST_TYPE, 'editor')): ?>
		<div class="w2gm-submit-section w2gm-submit-section-description">
			<h3 class="w2gm-submit-section-label"><?php echo $w2gm_instance->content_fields->getContentFieldBySlug('content')->name; ?><?php if ($w2gm_instance->content_fields->getContentFieldBySlug('content')->is_required): ?><span class="w2gm-red-asterisk">*</span><?php endif; ?></h3>
			<div class="w2gm-submit-section-inside">
				<?php wp_editor($w2gm_instance->current_listing->post->post_content, 'post_content', array('media_buttons' => false, 'editor_class' => 'w2gm-editor-class')); ?>
				<?php if ($w2gm_instance->content_fields->getContentFieldBySlug('content')->description): ?><p class="w2gm-description"><?php echo $w2gm_instance->content_fields->getContentFieldBySlug('content')->description; ?></p><?php endif; ?>
			</div>
		</div>
		<?php endif; ?>

		<?php if (post_type_supports(W2GM_POST_TYPE, 'excerpt')): ?>
		<div class="w2gm-submit-section w2gm-submit-section-excerpt">
			<h3 class="w2gm-submit-section-label"><?php echo $w2gm_instance->content_fields->getContentFieldBySlug('summary')->name; ?><?php if ($w2gm_instance->content_fields->getContentFieldBySlug('summary')->is_required): ?><span class="w2gm-red-asterisk">*</span><?php endif; ?></h3>
			<div class="w2gm-submit-section-inside">
				<textarea name="post_excerpt" class="w2gm-editor-class w2gm-form-control" rows="4"><?php echo esc_textarea($w2gm_instance->current_listing->post->post_excerpt)?></textarea>
				<?php if ($w2gm_instance->content_fields->getContentFieldBySlug('summary')->description): ?><p class="w2gm-description"><?php echo $w2gm_instance->content_fields->getContentFieldBySlug('summary')->description; ?></p><?php endif; ?>
			</div>
		</div>
		<?php endif; ?>
		
		<?php do_action('w2gm_create_listing_metaboxes_pre', $w2gm_instance->current_listing); ?>

		<?php if (!$w2gm_instance->current_listing->level->eternal_active_period && (get_option('w2gm_change_expiration_date') || current_user_can('manage_options'))): ?>
		<div class="w2gm-submit-section w2gm-submit-section-expiration-date">
			<h3 class="w2gm-submit-section-label"><?php _e('Listing expiration date', 'W2GM'); ?></h3>
			<div class="w2gm-submit-section-inside">
				<?php $w2gm_instance->listings_manager->listingExpirationDateMetabox($w2gm_instance->current_listing->post); ?>
			</div>
		</div>
		<?php endif; ?>

		<?php if (get_option('w2gm_listing_contact_form') && get_option('w2gm_custom_contact_email')): ?>
		<div class="w2gm-submit-section w2gm-submit-section-contact-email">
			<h3 class="w2gm-submit-section-label"><?php _e('Contact email', 'W2GM'); ?></h3>
			<div class="w2gm-submit-section-inside">
				<?php $w2gm_instance->listings_manager->listingContactEmailMetabox($w2gm_instance->current_listing->post); ?>
			</div>
		</div>
		<?php endif; ?>
		
		<?php if (get_option('w2gm_claim_functionality') && !get_option('w2gm_hide_claim_metabox')): ?>
		<div class="w2gm-submit-section w2gm-submit-section-claim">
			<h3 class="w2gm-submit-section-label"><?php _e('Listing claim', 'W2GM'); ?></h3>
			<div class="w2gm-submit-section-inside">
				<?php $w2gm_instance->listings_manager->listingClaimMetabox($w2gm_instance->current_listing->post); ?>
			</div>
		</div>
		<?php endif; ?>
	
		<?php if ($w2gm_instance->current_listing->level->categories_number > 0 || $w2gm_instance->current_listing->level->unlimited_categories): ?>
		<div class="w2gm-submit-section w2gm-submit-section-categories">
			<h3 class="w2gm-submit-section-label"><?php echo $w2gm_instance->content_fields->getContentFieldBySlug('categories_list')->name; ?><?php if ($w2gm_instance->content_fields->getContentFieldBySlug('categories_list')->is_required): ?><span class="w2gm-red-asterisk">*</span><?php endif; ?></h3>
			<div class="w2gm-submit-section-inside">
				<a href="javascript:void(0);" class="w2gm-expand-terms"><?php _e('Expand All', 'W2GM'); ?></a> | <a href="javascript:void(0);" class="w2gm-collapse-terms"><?php _e('Collapse All', 'W2GM'); ?></a>
				<div class="w2gm-categories-tree-panel w2gm-editor-class" id="<?php echo W2GM_CATEGORIES_TAX; ?>-all">
					<?php w2gm_terms_checklist($w2gm_instance->current_listing->post->ID); ?>
				</div>
				<?php if ($w2gm_instance->content_fields->getContentFieldBySlug('categories_list')->description): ?><p class="w2gm-description"><?php echo $w2gm_instance->content_fields->getContentFieldBySlug('categories_list')->description; ?></p><?php endif; ?>
			</div>
		</div>
		<?php endif; ?>
		
		<?php if (get_option('w2gm_enable_tags')): ?>
		<div class="w2gm-submit-section w2gm-submit-section-tags">
			<h3 class="w2gm-submit-section-label"><?php echo $w2gm_instance->content_fields->getContentFieldBySlug('listing_tags')->name; ?> <i>(<?php _e('select existing or type new', 'W2GM'); ?>)</i></h3>
			<div class="w2gm-submit-section-inside">
				<?php w2gm_tags_selectbox($w2gm_instance->current_listing->post->ID); ?>
				<?php if ($w2gm_instance->content_fields->getContentFieldBySlug('listing_tags')->description): ?><p class="w2gm-description"><?php echo $w2gm_instance->content_fields->getContentFieldBySlug('listing_tags')->description; ?></p><?php endif; ?>
			</div>
		</div>
		<?php endif; ?>
	
		<?php if ($w2gm_instance->content_fields->isNotCoreContentFields()): ?>
		<div class="w2gm-submit-section w2gm-submit-section-content-fields">
			<div class="w2gm-submit-section-inside">
				<?php $w2gm_instance->content_fields_manager->contentFieldsMetabox($w2gm_instance->current_listing->post); ?>
			</div>
		</div>
		<?php endif; ?>
	
		<?php if ($w2gm_instance->current_listing->level->images_number > 0 || $w2gm_instance->current_listing->level->videos_number > 0): ?>
		<div class="w2gm-submit-section w2gm-submit-section-media">
			<h3 class="w2gm-submit-section-label"><?php _e('Listing Media', 'W2GM'); ?></h3>
			<div class="w2gm-submit-section-inside">
				<?php $w2gm_instance->media_manager->mediaMetabox(); ?>
			</div>
		</div>
		<?php endif; ?>
	
		<?php if ($w2gm_instance->current_listing->level->locations_number > 0): ?>
		<div class="w2gm-submit-section w2gm-submit-section-locations">
			<h3 class="w2gm-submit-section-label"><?php _e('Listing locations', 'W2GM'); ?><?php if ($w2gm_instance->content_fields->getContentFieldBySlug('address')->is_required): ?><span class="w2gm-red-asterisk">*</span><?php endif; ?></h3>
			<div class="w2gm-submit-section-inside">
				<?php if ($w2gm_instance->content_fields->getContentFieldBySlug('address')->description): ?><p class="w2gm-description"><?php echo $w2gm_instance->content_fields->getContentFieldBySlug('address')->description; ?></p><?php endif; ?>
				<?php $w2gm_instance->locations_manager->listingLocationsMetabox($w2gm_instance->current_listing->post); ?>
			</div>
		</div>
		<?php endif; ?>
		
		<?php do_action('w2gm_create_listing_metaboxes_post', $w2gm_instance->current_listing); ?>

		<?php if (get_option('w2gm_enable_recaptcha')): ?>
		<div class="w2gm-submit-section-adv">
			<?php echo w2gm_recaptcha(); ?>
		</div>
		<?php endif; ?>

		<?php
		if ($tos_page = w2gm_get_wpml_dependent_option('w2gm_tospage')) : ?>
		<div class="w2gm-submit-section-adv">
			<label><input type="checkbox" name="w2gm_tospage" value="1" /> <?php printf(__('I agree to the ', 'W2GM') . '<a href="%s" target="_blank">%s</a>', get_permalink($tos_page), __('Terms of Services', 'W2GM')); ?></label>
		</div>
		<?php endif; ?>

		<?php require_once(ABSPATH . 'wp-admin/includes/template.php'); ?>
		<?php submit_button(__('Submit new listing', 'W2GM'), 'w2gm-btn w2gm-btn-primary')?>
	</form>
</div>