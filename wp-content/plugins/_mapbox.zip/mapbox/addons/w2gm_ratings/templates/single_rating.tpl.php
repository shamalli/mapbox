<div class="w2gm-rating">
	<div class="w2gm-rating-stars">
		<label class="w2gm-rating-icon w2gm-fa <?php echo $rating->render_star(5); ?>"></label>
		<label class="w2gm-rating-icon w2gm-fa <?php echo $rating->render_star(4); ?>"></label>
		<label class="w2gm-rating-icon w2gm-fa <?php echo $rating->render_star(3); ?>"></label>
		<label class="w2gm-rating-icon w2gm-fa <?php echo $rating->render_star(2); ?>"></label>
		<label class="w2gm-rating-icon w2gm-fa <?php echo $rating->render_star(1); ?>"></label>
	</div>
</div>