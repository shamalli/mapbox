<?php 

class w2mb_content_field_radio_search extends w2mb_content_field_select_search {

}
?>