<div class="w2mb-content">
	<?php w2mb_renderMessages(); ?>

	<h3><?php esc_html_e('Register For This Site.', 'W2MB') ?></h3>

	<div class="w2mb-submit-section-adv">
		<?php w2mb_registration_form(); ?>
	</div>
</div>