﻿=== MapBox Locator plugin for WordPress ===
Contributors: Mihail Chepovskiy
Donate link: http://www.salephpscripts.com/
Tags: directions, mapbox map, openstreetmap, listing, directory, markers, clusters, search form, places, polygons, routes, visual composer, wordpress, wpml, youtube
Requires at least: 3.6.2
Tested up to: 5.4.2
Stable tag: tags/1.0.4
License: Commercial

== Description ==

MapBox Locator plugin for WordPress to build custom MapBox (OpenStreetMap) maps with high quality markers and additional instruments. Frontend submission form allows users to submit markers and
listings from frontend of WordPress site. Search form filters markers and listings by categories, locations and content fields. Draw Area functionality is
the most perfect tool to search needed places in accurately pictured area.

Look at our [demo](http://www.salephpscripts.com/wordpress-mapbox/demo/)

== Changelog ==

= Version 1.0.4 =
* Initial release
