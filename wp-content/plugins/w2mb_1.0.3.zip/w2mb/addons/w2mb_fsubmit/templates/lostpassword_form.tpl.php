<div class="w2mb-content">
	<?php w2mb_renderMessages(); ?>

	<h3><?php esc_html_e('Please enter your username or email address. You will receive a link to create a new password via email.', 'W2MB') ?></h3>

	<div class="w2mb-submit-section-adv">
		<?php w2mb_lostpassword_form(); ?>
	</div>
</div>