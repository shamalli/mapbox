<?php esc_html_e('Listing title:', 'W2MB'); ?> <?php echo $listing_title; ?>

<?php esc_html_e('Listing URL:', 'W2MB'); ?> <?php echo $listing_url; ?>

<?php esc_html_e('Name:', 'W2MB'); ?> <?php echo $name; ?>

<?php esc_html_e('Email:', 'W2MB'); ?> <?php echo $email; ?>

<?php esc_html_e('Message:', 'W2MB'); ?>


<?php echo $message; ?>