<?php 

class w2mb_content_field_phone_search extends w2mb_content_field_string_search {

}
?>