<div class="vp-field <?php echo w2mb_esc($type); ?><?php echo !empty($container_extra_classes) ? (' ' . $container_extra_classes) : ''; ?>"
	data-vp-type="<?php echo w2mb_esc($type); ?>"
	<?php echo VP_W2MB_Util_Text::print_if_exists($validation, 'data-vp-validation="%s"'); ?>
	<?php echo VP_W2MB_Util_Text::print_if_exists(isset($binding) ? $binding : '', 'data-vp-bind="%s"'); ?>
	<?php echo VP_W2MB_Util_Text::print_if_exists(isset($items_binding) ? $items_binding : '', 'data-vp-items-bind="%s"'); ?>
	<?php echo VP_W2MB_Util_Text::print_if_exists(isset($dependency) ? $dependency : '', 'data-vp-dependency="%s"'); ?>
	id="<?php echo w2mb_esc($name); ?>">
	<div class="label">
		<label><?php echo w2mb_esc($label); ?></label>
		<?php VP_W2MB_Util_Text::print_if_exists($description, '<div class="description">%s</div>'); ?>
	</div>
	<div class="field">
		<div class="input">