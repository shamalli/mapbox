<?php if(!$is_compact) echo VP_W2MB_View::instance()->load('control/template_control_head', $head_info); ?>

<input class="vp-input" type="text" readonly id="<?php echo w2mb_esc($name); ?>" name="<?php echo w2mb_esc($name); ?>" value="<?php echo w2mb_esc($value); ?>" />
<div class="buttons">
	<input class="vp-js-upload vp-button button" type="button" value="<?php esc_attr_e('Choose File', 'W2MB'); ?>" />
	<input class="vp-js-remove-upload vp-button button" type="button" value="x" />
</div>
<div class="image">
	<img src="<?php echo w2mb_esc($preview); ?>" alt="" />
</div>

<?php if(!$is_compact) echo VP_W2MB_View::instance()->load('control/template_control_foot'); ?>