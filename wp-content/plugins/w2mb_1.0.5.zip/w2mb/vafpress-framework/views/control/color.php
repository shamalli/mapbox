<?php if(!$is_compact) echo VP_W2MB_View::instance()->load('control/template_control_head', $head_info); ?>

<label class="indicator" for="<?php echo w2mb_esc($name); ?>"><span style="background-color: <?php echo w2mb_esc($value); ?>;"></span></label>
<input id="<?php echo w2mb_esc($name); ?>" class="vp-input vp-js-colorpicker"
	type="text" name="<?php echo w2mb_esc($name); ?>" value="<?php echo w2mb_esc($value); ?>" data-vp-opt="<?php echo w2mb_esc($opt); ?>" />

<?php if(!$is_compact) echo VP_W2MB_View::instance()->load('control/template_control_foot'); ?>