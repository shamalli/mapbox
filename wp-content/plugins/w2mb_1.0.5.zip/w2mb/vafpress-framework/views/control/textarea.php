<?php if(!$is_compact) echo VP_W2MB_View::instance()->load('control/template_control_head', $head_info); ?>

<textarea class="vp-input" name="<?php echo w2mb_esc($name); ?>"><?php echo esc_attr($value); ?></textarea>

<?php if(!$is_compact) echo VP_W2MB_View::instance()->load('control/template_control_foot'); ?>