<?php if(!$is_compact) echo VP_W2MB_View::instance()->load('control/template_control_head', $head_info); ?>

<input type="text" name="<?php echo w2mb_esc($name); ?>" class="vp-input slideinput vp-js-tipsy" original-title="Range between <?php echo w2mb_esc($opt_raw['min']); ?> and <?php echo w2mb_esc($opt_raw['max']); ?>" value="<?php echo w2mb_esc($value); ?>" />
<div class="vp-js-slider slidebar" id="<?php echo w2mb_esc($name); ?>" data-vp-opt="<?php echo w2mb_esc($opt); ?>"></div>

<?php if(!$is_compact) echo VP_W2MB_View::instance()->load('control/template_control_foot'); ?>