<?php if ($content_field->value): ?>
	<a href="mailto:<?php echo w2mb_esc($email); ?>"><?php echo w2mb_esc($email); ?></a>
<?php endif; ?>