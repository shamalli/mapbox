<div class="w2mb-content">
	<?php w2mb_renderMessages(); ?>

	<div class="w2mb-submit-section-adv">
		<?php w2mb_login_form(); ?>
	</div>
</div>