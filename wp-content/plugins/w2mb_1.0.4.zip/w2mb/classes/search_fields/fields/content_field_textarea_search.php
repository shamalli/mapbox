<?php 

class w2mb_content_field_textarea_search extends w2mb_content_field_string_search {

}
?>