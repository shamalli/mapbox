<?php if ($content_field->value): ?>
	<a href="mailto:<?php echo $email; ?>"><?php echo $email; ?></a>
<?php endif; ?>