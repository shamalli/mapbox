<div class="w2mb-rating">
	<div class="w2mb-rating-stars">
		<label class="w2mb-rating-icon w2mb-fa <?php echo $rating->render_star(5); ?>"></label>
		<label class="w2mb-rating-icon w2mb-fa <?php echo $rating->render_star(4); ?>"></label>
		<label class="w2mb-rating-icon w2mb-fa <?php echo $rating->render_star(3); ?>"></label>
		<label class="w2mb-rating-icon w2mb-fa <?php echo $rating->render_star(2); ?>"></label>
		<label class="w2mb-rating-icon w2mb-fa <?php echo $rating->render_star(1); ?>"></label>
	</div>
</div>